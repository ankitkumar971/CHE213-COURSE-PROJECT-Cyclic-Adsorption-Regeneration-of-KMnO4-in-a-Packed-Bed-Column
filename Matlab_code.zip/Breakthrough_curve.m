clear; clc; close all;

% ===== DATA =====
t1 = 0:2:60;
C1 = [0.0093 0.0142 0.0093 0.0142 0.0093 0.0093 0.0142 0.0142 ...
      0.0142 0.0142 0.0142 0.0195 0.0195 0.0254 0.0318 0.0387 ...
      0.0541 0.0809 0.0908 0.1483 0.2034 0.2790 0.4604 0.5306 ...
      0.6083 0.7276 0.8160 0.8492 0.8851 0.8492 0.8851];

t2 = 0:2:56;
C2 = [0.0142 0.0142 0.0142 0.0142 0.0142 0.0195 0.0195 0.0254 ...
      0.0254 0.0318 0.0387 0.0461 0.0541 0.0714 0.0908 0.1123 ...
      0.1888 0.2340 0.3013 0.4387 0.5284 0.6520 0.7600 0.8171 ...
      0.8762 0.9066 0.9374 0.9066 0.9374];

%% ===== BREAKTHROUGH =====
idx_b1 = find(C1 >= 0.1, 1);
idx_b2 = find(C2 >= 0.1, 1);

tb1 = interp1(C1(idx_b1-1:idx_b1), t1(idx_b1-1:idx_b1), 0.1);
tb2 = interp1(C2(idx_b2-1:idx_b2), t2(idx_b2-1:idx_b2), 0.1);

%% ===== SATURATION (FINAL METHOD) =====
threshold = 0.95;

idx_s1 = find(C1 >= threshold, 1);
idx_s2 = find(C2 >= threshold, 1);

if isempty(idx_s1)
    ts1 = t1(end);      % 60 min
    Cs1 = C1(end);
else
    ts1 = t1(idx_s1);
    Cs1 = C1(idx_s1);
end

if isempty(idx_s2)
    ts2 = t2(end);      % 56 min
    Cs2 = C2(end);
else
    ts2 = t2(idx_s2);
    Cs2 = C2(idx_s2);
end

%% ===== PLOT =====
figure;

plot(t1, C1, 'o-b','LineWidth',2); hold on;
plot(t2, C2, 's--r','LineWidth',2);

% Breakthrough line
yline(0.1,'r--','LineWidth',1.2);

% Ideal saturation line
yline(1,'k--','LineWidth',1.2);

% Mark breakthrough
plot(tb1,0.1,'ro','MarkerFaceColor','r');
plot(tb2,0.1,'ro','MarkerFaceColor','r');

text(tb1,0.14,sprintf('Cycle 1: %.1f min',tb1));
text(tb2,0.18,sprintf('Cycle 2: %.1f min',tb2));

% Mark saturation
plot(ts1,Cs1,'ko','MarkerFaceColor','k');
plot(ts2,Cs2,'ko','MarkerFaceColor','k');

text(ts1-6,Cs1+0.05,'Cycle 1: 60 min*');
text(ts2-6,Cs2+0.05,'Cycle 2: 56 min');

% Annotation
annotation('textarrow',[0.45 0.35],[0.65 0.55],...
'String','Left shift → reduced adsorption capacity');

xlabel('Time (min)');
ylabel('C/C_0');
title('Breakthrough Curve Showing Effect of Regeneration');

legend('Cycle 1 (Fresh Bed)','Cycle 2 (Regenerated)','Location','northwest');

grid on;
xlim([0 60]);
ylim([0 1.1]);

set(gca,'FontSize',12,'LineWidth',1.2);
%% ===== DISPLAY RESULTS =====

fprintf('\n===== FINAL RESULTS =====\n');

fprintf('\nCycle 1 (Fresh Bed):\n');
fprintf('Breakthrough Time = %.2f min\n', tb1);
fprintf('Saturation Time   = %.2f min', ts1);

if isempty(idx_s1)
    fprintf('  (not fully reached)\n');
else
    fprintf('\n');
end

fprintf('\nCycle 2 (Regenerated Bed):\n');
fprintf('Breakthrough Time = %.2f min\n', tb2);
fprintf('Saturation Time   = %.2f min\n', ts2);

% ===== LUB & Efficiency =====
Z = 1;  % bed height

LUB1 = Z * (ts1 - tb1) / ts1;
eta1 = (1 - LUB1/Z) * 100;

LUB2 = Z * (ts2 - tb2) / ts2;
eta2 = (1 - LUB2/Z) * 100;

fprintf('\n===== PERFORMANCE =====\n');

fprintf('\nCycle 1:\n');
fprintf('LUB = %.3f m\n', LUB1);
fprintf('Efficiency = %.2f %%\n', eta1);

fprintf('\nCycle 2:\n');
fprintf('LUB = %.3f m\n', LUB2);
fprintf('Efficiency = %.2f %%\n', eta2);

% ===== % Changes =====
eff_drop = (eta1 - eta2)/eta1 * 100;
lub_increase = (LUB2 - LUB1)/LUB1 * 100;
bt_drop = (tb1 - tb2)/tb1 * 100;

fprintf('\n===== PERFORMANCE CHANGE =====\n');
fprintf('Breakthrough decrease = %.1f %%\n', bt_drop);
fprintf('Efficiency decrease   = %.1f %%\n', eff_drop);
fprintf('LUB increase          = %.1f %%\n', lub_increase);