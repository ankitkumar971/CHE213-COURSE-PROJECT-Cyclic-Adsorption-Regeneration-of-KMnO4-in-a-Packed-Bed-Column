clear
clc
close all
% Quadratic fit coefficients (from your slide)
a = 9.2e-3;
b = 1.3e-3;
c = 3.9e-6;

% C0 (feed concentration)
C0 = 3.615e-3;

%% ================== TABLE 2 (Cycle 1) ==================
time1 = 0:2:60;

A1 = [0.02 0.03 0.02 0.03 0.02 0.02 0.03 0.03 0.03 0.03 ...
      0.03 0.04 0.04 0.05 0.06 0.07 ...
      0.09 0.12 0.13 0.18 0.22 0.27 0.36 0.39 ...
      0.42 0.47 0.50 0.51 0.52 0.51 0.52];

% Calculate concentration
C1 = a*A1.^2 + b*A1 + c;

% Calculate C/C0
ratio1 = C1 / C0;

% Display table
Table2 = table(time1', A1', C1', ratio1', ...
    'VariableNames', {'Time_min','A','C_mol_L','C_by_C0'});

disp('TABLE 2: Adsorption Data');
disp(Table2);


%% ================== TABLE 3 (Cycle 2) ==================
time2 = 0:2:56;

A2 = [0.03 0.03 0.03 0.03 0.03 0.04 0.04 0.05 0.05 0.06 ...
      0.07 0.08 0.09 0.11 0.13 0.15 ...
      0.21 0.24 0.28 0.35 0.39 0.44 0.48 0.50 ...
      0.52 0.53 0.54 0.53 0.54];

% Calculate concentration
C2 = a*A2.^2 + b*A2 + c;

% Calculate C/C0
ratio2 = C2 / C0;

% Display table
Table3 = table(time2', A2', C2', ratio2', ...
    'VariableNames', {'Time_min','A','C_mol_L','C_by_C0'});

disp('TABLE 3 : Regeneration Data');
disp(Table3);