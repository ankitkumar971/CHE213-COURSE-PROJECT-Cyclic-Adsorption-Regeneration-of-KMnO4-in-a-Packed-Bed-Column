clc
clear
close all

% ===== Given =====
C_stock = 3.615e-3;   % mol/L
V_total = 10;         % mL

% KMnO4 volumes
V_KMnO4 = 0:10;

% Water volumes
V_water = V_total - V_KMnO4;

% ===== Calculate concentration =====
C = C_stock * (V_KMnO4 / V_total);

% ===== Absorbance values (given) =====
A = [0.00 0.15 0.21 0.27 0.33 0.38 0.42 0.46 0.50 0.53 0.55];

% ===== Display table =====
Table1 = table(V_KMnO4', V_water', C', A', ...
    'VariableNames', {'KMnO4_mL','Water_mL','Concentration_mol_L','Absorbance'});

disp('Calibration Table:');
disp(Table1);