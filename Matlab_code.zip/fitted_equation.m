% Calibration data (Table 1)
A = [0.00 0.15 0.21 0.27 0.33 0.38 0.42 0.46 0.50 0.53 0.55];
C = [0 3.615e-4 7.23e-4 1.0845e-3 1.446e-3 1.8075e-3 ...
     2.169e-3 2.5305e-3 2.892e-3 3.2535e-3 3.615e-3];

% Quadratic fit
p = polyfit(A, C, 2);

a = p(1);
b = p(2);
c = p(3);

% Display coefficients
fprintf('a = %e\n', a);
fprintf('b = %e\n', b);
fprintf('c = %e\n', c);

% Display equation
fprintf('\nFitted Equation:\n');
fprintf('C = %.3e A^2 + %.3e A + %.3e\n', a, b, c);