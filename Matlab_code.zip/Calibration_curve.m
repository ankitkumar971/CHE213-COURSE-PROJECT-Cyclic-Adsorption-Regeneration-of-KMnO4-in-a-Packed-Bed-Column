clc; clear;

% Calibration data
A = [0.00 0.15 0.21 0.27 0.33 0.38 0.42 0.46 0.50 0.53 0.55];
C = [0 3.615e-4 7.23e-4 1.0845e-3 1.446e-3 1.8075e-3 ...
     2.169e-3 2.5305e-3 2.892e-3 3.2535e-3 3.615e-3];

% Quadratic fit
p = polyfit(A, C, 2);

% Smooth curve
A_fit = linspace(0, 0.6, 100);
C_fit = polyval(p, A_fit);

figure;
plot(A, C, 'bo-', 'LineWidth', 1.5); hold on;
plot(A_fit, C_fit, 'r--', 'LineWidth', 1.5);

xlabel('Absorbance (A)');
ylabel('Concentration (mol/L)');
title('Calibration Curve for KMnO_4');
legend('Experimental Data', 'Quadratic Fit');
grid on;